package com.example.friendsapp;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {



    // Variables to store quiz questions and answers
    private String[] questions = {"The series Friends is set in which city?", "What is Monica skilled at?", "What’s the name of the 1950s-themed diner where Monica worked as a waitress", "What song is Phoebe best known for?", "What does Joey never share?"};
    private String[][] choices = {
            {"LA", "New York City", "Miami", "Seattle"},
            {"Cooking", "Singing", "Dancing", "Driving"},
            {"Marilyn & Audrey", "Twilight Galaxy", "Moondance Diner", "Marvin’s"},
            {"Smelly Cat", "Smelly Dog", "Smelly Rabbit", "Smelly Worm"},
            {"Books", "Information", "Food", "Movies"}
    };
    private int[] answers = {1, 0, 2, 0, 2};
    private int currentQuestionIndex = 0;
    private int score = 0;

    private TextView questionTextView;
    private RadioGroup choicesRadioGroup;
    private Button submitButton;
    private Button nextButton;

    private Button homeButton;
    private TextView scoreTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        displayQuestion();
        setOnClickListeners();
    }

    private void initializeViews() {
        questionTextView = findViewById(R.id.question_text_view);
        choicesRadioGroup = findViewById(R.id.choices_radio_group);
        submitButton = findViewById(R.id.submit_button);
        nextButton = findViewById(R.id.next_button);
        homeButton = findViewById(R.id.home_button);
        scoreTextView = findViewById(R.id.score_text_view);

    }

    private void setOnClickListeners() {
        submitButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                int selectedChoiceIndex = choicesRadioGroup.getCheckedRadioButtonId();
                if (selectedChoiceIndex == -1) {
                    Toast.makeText(MainActivity.this, "Please select an answer", Toast.LENGTH_SHORT).show();

                } else {

                    selectedChoiceIndex = choicesRadioGroup.indexOfChild(findViewById(selectedChoiceIndex));
                    if (selectedChoiceIndex == answers[currentQuestionIndex]) {
                        Toast.makeText(MainActivity.this, "Correct!", Toast.LENGTH_SHORT).show();
                        score++;

                    } else {

                        Toast.makeText(MainActivity.this, "Incorrect!", Toast.LENGTH_SHORT).show();

                    }

                    scoreTextView.setText("Score: " + score + "/" + questions.length);
                }
            }

        });

        nextButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                currentQuestionIndex = (currentQuestionIndex + 1) % questions.length;
                displayQuestion();
                choicesRadioGroup.clearCheck();
            }
        });

        homeButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),Frontpage.class));

            }
        });
    }

    private void displayQuestion() {
        questionTextView.setText(questions[currentQuestionIndex]);
        choicesRadioGroup.removeAllViews();
        for (int i = 0; i < choices[currentQuestionIndex].length; i++) {
            RadioButton radioButton = new RadioButton(this);
            radioButton.setId(i);
            radioButton.setText(choices[currentQuestionIndex][i]);
            choicesRadioGroup.addView(radioButton);
        }
    }
}
